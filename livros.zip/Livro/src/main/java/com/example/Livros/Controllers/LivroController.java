package com.example.Livros.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Livros.Entities.Livro;
import com.example.Livros.Services.LivrosService;


@RestController
@RequestMapping("/livro")

public class LivroController {
	@Autowired
    private final LivrosService livrosService;

    @Autowired
    public LivroController(LivrosService livrosService) {
        this.livrosService = livrosService;
    }

    @PostMapping
    public Livro createLivro(@RequestBody Livro livro) {
        return livrosService.saveLivro(livro);
    }

    @GetMapping("/{id}")
    public Livro getLivro(@PathVariable Long id) {
        return livrosService.getLivroById(id);
    }

    @GetMapping
    public List<Livro> getAllLivro() {
        return livrosService.getAllLivro();
    }

    @DeleteMapping("/{id}")
    public void deleteLivro(@PathVariable Long id) {
        livrosService.deleteLivro(id);
    }
}

