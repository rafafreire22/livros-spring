package com.example.Livros.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Livros.Entities.Livro;

public interface LivroRepository extends JpaRepository<Livro, Long> {

}
