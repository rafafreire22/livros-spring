package com.example.Livros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LivroApplicationTests {

	@Test
	void contextLoads() {
	}

}
